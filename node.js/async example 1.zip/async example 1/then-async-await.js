// HELPERS
function buildStFromIterable(iterableObj) {
    let st = '';
    for (let key of iterableObj.keys) {
        st += obj.key;
    }
    return st;
}

function qs(whichElems) {
    return document.querySelector(whichElems);
}
//====================================================
let myAsyncAwaitVersionOfFetching = async (event) => {
    console.log(event.type);
    let url = 'https://dog.ceo/api/breeds/image/random';
    //  add "loading indicator" to our page should go here
    let response = await fetch(url);
    if (response.ok) { // if HTTP-status is 200-299
        // get the response body 
        let json = await response.json();
        qs('#myP').innerHTML = JSON.stringify(json);
        qs('#div1').innerHTML = `<img src=${JSON.stringify(json.message)} alt=dog>`;
    } else {
        alert("HTTP-Error: " + response.status);
    }
}
//====================================================
let myThenVersionOfFetch = (event) => {
    console.log(event.type);
    let url = 'https://dog.ceo/api/breeds/image/random';
    fetch(url)
        .then((response) => {
            console.log(response.status);
            console.log(response);
            return response.json()
        })
        .then((data) => {
            console.log(data.message);
            qs('#myP').innerHTML = JSON.stringify(data);
            qs('#div1').innerHTML = `<img height="300" src=${JSON.stringify(data.message)} alt=dog>`;
        })
        .catch((theResponse) => {
            alert("HTTP-Error: " + theResponse.status);
        })
}
//====================================================
// lets use the above functions:
//window.addEventListener('load', (event)=>console.log('load'));

//   Version async await
// document.addEventListener('DOMContentLoaded', myAsyncAwaitVersionOfFetching);

//   Version then
document.addEventListener('DOMContentLoaded', myThenVersionOfFetch);






//========================== another example we did in class =======
/*
let myAsyncAwaitVersionOfFetching = async (event) => {
    console.log(event.type);
    let url = 'https://dog.ceo/api/breeds/image/random';
    //  add "loading indicator" to our page should go here
    qs("#div1").innerHTML = `<iframe src="https://giphy.com/embed/3oEjI6SIIHBdRxXI40" width="480" height="480" frameBorder="0" class="giphy-embed" allowFullScreen></iframe><p><a href="https://giphy.com/gifs/mashable-3oEjI6SIIHBdRxXI40">via GIPHY</a></p>`
    setTimeout(async () => {
        let response = await fetch(url);
        if (response.ok) { // if HTTP-status is 200-299
            // get the response body
            let json = await response.json();
            qs('#myP').innerHTML = JSON.stringify(json);
            qs('#div1').innerHTML = `<img src=${JSON.stringify(json.message)} alt=dog>`;
        } else {
            alert("HTTP-Error: " + response.status);
        }
    }, 3000)
}
*/


